# In order to Run the program locally
1. Create a virtual environment
    `virtualenv venv`

2. Activate it
    `Source venv\bin\activate`

3. Install all packages and dependencies with
    `pip install - r requirements.txt`

4. For collecting Dataset,
    run  `python data_collection_final.py`

5. finally, Run `python final_pred.py` for Good Gui.