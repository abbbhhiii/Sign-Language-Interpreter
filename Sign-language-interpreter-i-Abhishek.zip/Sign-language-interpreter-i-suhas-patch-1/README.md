# sign-language-interpreter
Sign language is widely used by individuals with hearing or speech impairments, but it is not commonly understood by others. Translating sign language into text can greatly enhance communication
